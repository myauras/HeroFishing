var classgame_behaviour_1_1check_state =
[
    [ "checkState", "classgame_behaviour_1_1check_state.html#a878672a2a013c1e4a2636349964fd6d5", null ],
    [ "Act", "classgame_behaviour_1_1check_state.html#aebab45c5d36462a69980e78659746967", null ],
    [ "DoBeforeEntering", "classgame_behaviour_1_1check_state.html#a6e43295b22e4f089218d1fe3eb21a5a3", null ],
    [ "DoBeforeLeaving", "classgame_behaviour_1_1check_state.html#a06e86f9e61d5e93d00205b4b7aa94a58", null ],
    [ "Reason", "classgame_behaviour_1_1check_state.html#a3a9ac78ba63b8f50c5dc1225423c8903", null ]
];