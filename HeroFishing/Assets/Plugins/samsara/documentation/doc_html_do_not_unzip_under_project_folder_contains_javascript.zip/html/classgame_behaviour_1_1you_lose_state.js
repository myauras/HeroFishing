var classgame_behaviour_1_1you_lose_state =
[
    [ "youLoseState", "classgame_behaviour_1_1you_lose_state.html#ac5679808d7b06fc54da550a09ecc8e41", null ],
    [ "Act", "classgame_behaviour_1_1you_lose_state.html#afb81ecce325009ce3dd65b2e71500c31", null ],
    [ "DoBeforeEntering", "classgame_behaviour_1_1you_lose_state.html#a8da173e86d075003882ac5894ab21cc6", null ],
    [ "DoBeforeLeaving", "classgame_behaviour_1_1you_lose_state.html#aeeb0321673ecf6a980ae81df0612fb80", null ],
    [ "Reason", "classgame_behaviour_1_1you_lose_state.html#aa9f41b46c1707cd2684bf9e5deed3c59", null ]
];