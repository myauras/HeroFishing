var classmusic_button_icon_behaviour =
[
    [ "action", "classmusic_button_icon_behaviour.html#aefa1d3671653e54aa8d07b0c5f4e3b1c", null ],
    [ "setIcon", "classmusic_button_icon_behaviour.html#a4282ac0ad3b5f7b7221c931f2b4afdcf", null ],
    [ "iconOff", "classmusic_button_icon_behaviour.html#a761e0758be5f6cf33984b112694f9fd9", null ],
    [ "iconOn", "classmusic_button_icon_behaviour.html#a535fa1e98ddc366ac0edb2bd151bd58c", null ]
];