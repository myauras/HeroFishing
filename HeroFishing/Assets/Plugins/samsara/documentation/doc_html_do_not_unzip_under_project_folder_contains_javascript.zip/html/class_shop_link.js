var class_shop_link =
[
    [ "link", "class_shop_link.html#af77c6683e1ec773c99d1a75998f48740", null ],
    [ "ImageSource", "class_shop_link.html#a8759ebefe1a0b64ec8fa605dcb951258", null ],
    [ "ProductDescription", "class_shop_link.html#a73d7513cf45caeee7f3dd9fc11902a4a", null ],
    [ "ProductLink", "class_shop_link.html#a68f154cd452b9d7f92504eb6bcbb7c45", null ],
    [ "ProductName", "class_shop_link.html#a5383b19bf868dcf19bfcbf71fefd0b6a", null ],
    [ "ProductPrice", "class_shop_link.html#a5a61a0d43e96cac441c033e510ed570d", null ]
];