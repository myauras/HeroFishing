var class_shop_controller =
[
    [ "msgOnFail", "class_shop_controller.html#aff9161d7f5734ef9cd68614158bd1643", null ],
    [ "url", "class_shop_controller.html#a8c4892da9a5d5d6117f1605533ac2d2f", null ]
];