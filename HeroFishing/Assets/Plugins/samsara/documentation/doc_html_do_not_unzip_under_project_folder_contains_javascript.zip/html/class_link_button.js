var class_link_button =
[
    [ "action", "class_link_button.html#a144e43e62e680ec2e06d4f56f8ec2c4f", null ],
    [ "link", "class_link_button.html#ae2545e4d2ce0688e9c38f66065b2cb68", null ]
];