var interface_i_product =
[
    [ "ImageSource", "interface_i_product.html#a1365f4fe31a97b986ef01a74fc7538c3", null ],
    [ "ProductDescription", "interface_i_product.html#ae9932027a7566ff559eb023499774198", null ],
    [ "ProductLink", "interface_i_product.html#a48cb5e1fcee06292f3f9178c8b2c1103", null ],
    [ "ProductName", "interface_i_product.html#ac649b9ea23a046039371bde43561d65e", null ],
    [ "ProductPrice", "interface_i_product.html#ae0af965e1d1b50370acd7c58b0c2c7bc", null ]
];