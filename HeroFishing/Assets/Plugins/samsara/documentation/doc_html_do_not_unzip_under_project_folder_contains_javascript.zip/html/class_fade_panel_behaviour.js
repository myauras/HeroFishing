var class_fade_panel_behaviour =
[
    [ "fadeIn", "class_fade_panel_behaviour.html#a4fc164572a14b457c447b1315fe48252", null ],
    [ "fadeInFlag", "class_fade_panel_behaviour.html#a2148b79e5493a2452f59af3af689a7b9", null ],
    [ "fadeTime", "class_fade_panel_behaviour.html#a4cc223d7e8d01e75d4420578dca929c2", null ]
];