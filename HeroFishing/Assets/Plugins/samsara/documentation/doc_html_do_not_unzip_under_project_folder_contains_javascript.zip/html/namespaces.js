var namespaces =
[
    [ "game_core", "namespacegame__core.html", null ]
];