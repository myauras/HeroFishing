var searchData=
[
  ['destroybanner',['DestroyBanner',['../class_admob_manager.html#a9291f88915151f471f110d2decc4cef8',1,'AdmobManager']]],
  ['destroyinterstitial',['DestroyInterstitial',['../class_admob_manager.html#ac21426be8da524a5e173f0c48cdcdc2d',1,'AdmobManager']]],
  ['dobeforeentering',['DoBeforeEntering',['../classgame_behaviour_1_1init_state.html#acb856959b74378f56593f9077d5a4abb',1,'gameBehaviour.initState.DoBeforeEntering()'],['../classgame_behaviour_1_1idle_state.html#a443e0bd9c747d2ee0d1903b56d34c1c9',1,'gameBehaviour.idleState.DoBeforeEntering()']]],
  ['dobeforeleaving',['DoBeforeLeaving',['../classgame_behaviour_1_1init_state.html#a04c5de844ae6fd7fa24e288268180b19',1,'gameBehaviour.initState.DoBeforeLeaving()'],['../classgame_behaviour_1_1idle_state.html#af14f471c5fb385998e4a9291e052fa25',1,'gameBehaviour.idleState.DoBeforeLeaving()']]]
];
