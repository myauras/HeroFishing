var searchData=
[
  ['getdeviceid',['GetDeviceID',['../class_admob_manager.html#a32c09bfd9da161c10420708bdd768093',1,'AdmobManager']]],
  ['getlast',['getLast',['../class_finger_event.html#a6f37faa3835b4bda41fa30564b1bb888',1,'FingerEvent']]]
];
