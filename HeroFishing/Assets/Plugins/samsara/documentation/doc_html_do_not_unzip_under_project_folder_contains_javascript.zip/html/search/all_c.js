var searchData=
[
  ['reason',['Reason',['../classgame_behaviour_1_1init_state.html#a4423204a9afa42adb3179198f81e6ccd',1,'gameBehaviour.initState.Reason()'],['../classgame_behaviour_1_1idle_state.html#a054c732d9d2f3bbbf1a33212ca1d1877',1,'gameBehaviour.idleState.Reason()']]],
  ['remove',['remove',['../class_finger_event.html#a2fee0821cb75c4d6d2449cb5e4651650',1,'FingerEvent']]],
  ['requestbanner',['RequestBanner',['../class_admob_manager.html#a023d76e512de812bcb863d340343d9b7',1,'AdmobManager']]],
  ['requestinterstitial',['RequestInterstitial',['../class_admob_manager.html#a12ecad797dd7001bcc6be7a478e701ce',1,'AdmobManager']]],
  ['resetgame',['resetGame',['../classgame_behaviour.html#a4ccbdba3fc05b71974b49bdb9fc77a1d',1,'gameBehaviour']]],
  ['resetscore',['resetScore',['../classgame_behaviour.html#a290fb3e938d6a137c30513a7582104a2',1,'gameBehaviour']]]
];
