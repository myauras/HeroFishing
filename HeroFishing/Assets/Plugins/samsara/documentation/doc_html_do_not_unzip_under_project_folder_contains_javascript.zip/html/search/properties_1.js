var searchData=
[
  ['imagesource',['ImageSource',['../class_shop_link.html#a8759ebefe1a0b64ec8fa605dcb951258',1,'ShopLink']]],
  ['instance',['Instance',['../class_admob_manager.html#a3bad55f5e73fbb1aceeaabd8011ef518',1,'AdmobManager.Instance()'],['../class_level_manager.html#a4e58c52b52fc7486c8f6ede86867be7b',1,'LevelManager.Instance()']]],
  ['isbannerrequested',['isBannerRequested',['../class_admob_manager.html#ac58ff4319e08f98ac8ffc4aca62f1838',1,'AdmobManager']]]
];
