var class_stats_data =
[
    [ "variableName", "class_stats_data.html#ab518bb686699cb29b4da309de52e68c9", null ]
];