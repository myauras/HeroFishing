var interfacegame__core_1_1_i_touchable =
[
    [ "OnTouchBegan", "interfacegame__core_1_1_i_touchable.html#a6721ed9f34a6cc05a130879d7d703800", null ],
    [ "OnTouchCanceled", "interfacegame__core_1_1_i_touchable.html#a925a4153fce35c887e45983d13e3cf5d", null ],
    [ "OnTouchEnded", "interfacegame__core_1_1_i_touchable.html#a459f162735c4a67560b4a9ceda5055d4", null ],
    [ "OnTouchMoved", "interfacegame__core_1_1_i_touchable.html#a09faee2116dc7951ac087941f513fc0b", null ]
];